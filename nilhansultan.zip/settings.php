<?php 

	//$content = $_SERVER['DOCUMENT_ROOT'] . '/json/content.json';
	//$content = _decode_json($content);

	$rename_path = 'images/articles/sanatcilar/';

	/* HEADER */

	$contact_us = false;

	/* LANDING PAGE */
	$slider_autoplayspeed = 5000;
	$slider_fadespeed = 1000;

	/* LANGUAGE */
	$language = array ('tr', 'en');

	/* SETTINGS */
	$erkajans = 'true';
	$under_construction = 'true';

	/* GOOGLE ANALYTICS */
	$google_analytics = 'UA-1289368-70';

?>