<?php   
    include_once 'include/landing-page/story-1.php';
    include_once 'include/landing-page/story-2.php';
    include_once 'include/landing-page/story-3.php';
 ?>

<?php 
    include_once 'include/landing-page/story-4.php';
	include_once 'include/landing-page/story-5.php';
    include_once 'include/landing-page/story-6.php';
    include_once 'include/landing-page/story-7.php';
?>
