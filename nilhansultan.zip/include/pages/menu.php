<div id="page_caption" class="hasbg parallax baseline ">
    <div class="parallax_overlay_header"></div>
    <div id="bg_regular" style="background-image:url(upload/abreakey-raw-foodphotography-squid-still-life.jpg);"></div>


    <div class="page_title_wrapper baseline" data-stellar-ratio="1.3">
        <div class="page_title_inner baseline">
            <h1 class="withtopbar">
                <span class="ppb_title_first" >Our</span>Menü
            </h1>
        </div>
    </div>
</div>

<div class="ppb_wrapper hasbg withtopbar">
    <div class="one" style="padding:50px 0 50px 0;">
        <div class="standard_wrapper">
            <div class="page_content_wrapper">
                <div class="inner">
                    <div style="margin:auto;width:100%;text-align:center;">
                        <h2 class="ppb_menu_title">ÇORBALAR</h2>
                        <br class="clear" />
                        <br/>
                        <div class="one_half ">
                            <div id="menu_3197" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">Taneli Sebze Çorbası</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Patates / Havuç / Kabak</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3172" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">Bütün Çorba (Soğuk Çorba)</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Buğday / Nohut / Yoğurt</div>
                            </div>
                        </div>
                    </div>
                    <br class="clear" />
                </div>
            </div>
        </div>
    </div>
    <div class="parallax title" data-image="upload/223_1r140806_eat_spots_sobanndls.jpg" data-width="1440" data-height="960" data-content-height="60">
        <div class="parallax_title">
            <h2 class="ppb_title"></div>
    </div>
    <div class="one" style="padding:50px 0 50px 0;">
        <div class="standard_wrapper">
            <div class="page_content_wrapper">
                <div class="inner">
                    <div style="margin:auto;width:100%;text-align:center;">
                        <h2 class="ppb_menu_title">BAŞLANGIÇLAR</h2>
                        <br class="clear" />
                        <br/>
                        <div class="one_half ">
                            <div id="menu_3197" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">MASTABE</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Süzme Yoğurt / Pazı / Çörek otu</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3172" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">KÖZLENMİŞ PATLICAN SALATASI</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Patlıcan / Zeytinyağı / Limon</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3173" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">TERBİYELİ LEVREK</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Levrek / Rezene / Sirke</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3174" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">HUMUS</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Nohut / Tahin / Sızma Zeytinyağı</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3175" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">TARHUNLU CACIK</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Süzme Yoğurt / Salatalık / Taze Tarhun</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3176" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">SOĞUK ÇORBA</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Süzme Yoğurt / Buğday / Nohut</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3177" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">VİŞNELİ ZEYTİNYAĞLI YAPRAK SARMA</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Pirinç / Kuş Üzümü / Dolmalık Fıstık</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">ENGİNAR VE ZAHTERLİ KARİDES SALATASI</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Enginar / Karides / Zahter</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">ZEYTİNYAĞLI ENGİNAR</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Enginar / Sızma Zeytinyağı / Limon</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">ZEYTİNYAĞLI REZENE</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Rezene / Portakal Suyu / Portakal Dilimleri</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">ENGİNAR VE ZAHTERLİ KARİDES SALATASI</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Karides / Havuç / Kereviz Sapı</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">SEMİZOTU SALATASI</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Semizotu / Sarı - Kırmızı Çeri Domates / Çilek</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">KORUK SULU ÇOBAN SALATA</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Domates / Salatalık / Köy Biberi</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">MAŞ SALATASI</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Maş Fasulyesi / Dereotu / Maydanoz</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">MEVSİM SALATASI</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Havuç / Kırmızı Lahana / Göbek Marul</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">KABAK TAVA</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Sakız Kabağı / Un / Nişasta</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">NANELİ YOĞURT</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Yoğurt / Nane </div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">PUF BÖREĞİ</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Un / Tereyağı / Peynir</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">ÖRDEK ETLİ PİROHİ</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Un / Yumurta / Ördek Eti</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">CEVİZLİ TEREYAĞI</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Ceviz / Tereyağı </div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">BORAN-İ HASSA</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Pazı / Badem / Karabiber</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">ÇILBIR</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Yumurta / Sirke / Tuz</div>
                            </div>
                        </div>

                    </div>
                    <br class="clear" />
                </div>
            </div>
        </div>
    </div>
    <div class="parallax title" data-image="upload/223_1r140806_eat_spots_sobanndls.jpg" data-width="1440" data-height="960" data-content-height="60">
        <div class="parallax_title">
            <h2 class="ppb_title"></h2></div>
    </div>
    <div class="one" style="padding:50px 0 50px 0;">
        <div class="standard_wrapper">
            <div class="page_content_wrapper">
                <div class="inner">
                    <div style="margin:auto;width:100%;text-align:center;">
                        <h2 class="ppb_menu_title">ANA YEMEKLER</h2>
                        <br class="clear" />
                        <br/>
                        <div class="one_half ">
                            <div id="menu_3197" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">KUZU İNCİK</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Kuzu İncik / Tereyağı / Tuz</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3172" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">DÖVME KEŞKEK</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Buğday / Et Suyu / Pul Biber</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3173" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">KAĞITTA LEVREK</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Levrek / Kabak / Havuç</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3174" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">KANLICA MANTAR, ARPACIK SOĞAN İLE TEREYAĞLI VE SARIMSAKLI İSKORPİT KAVURMA</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">İskorpit Balığı / Sarımsak / Kanlıca Mantar</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3175" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">AL’A NAZİK</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Patlıcan / Kuzu Eti / Sarımsak</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3176" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">HÜNKAR BEĞENDİ</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Dana Eti / Salça / Baharatlar</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3177" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">DAMLA SAKIZLI BEĞENDİ</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Patlıcan / Damla Sakızı / Süt</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">BALLI MAHMUDİYE</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Tavuk (Kalça) / Badem / Sirke</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3177" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">KEBAB-I MAKİYAN (1469)</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Tavuk But / Yenibahar / Tarçın</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">KARAMELİZE SOĞAN</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Kuru soğan / Tarçın / Şeker</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3177" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">KIYMA PÜRYANİ YUFKADA (1764)</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Kuzu Eti Kıyması / Tavuk Eti Kıyması / Anason</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">DANE-İ SARI (1539)</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Pirinç / Nohut / Safran</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3177" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">İÇ PİLAV</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Pirinç / Kara Ciğer / Kuş Üzümü</div>
                            </div>
                        </div>
                    </div>
                    <br class="clear" />
                </div>
            </div>
        </div>
    </div>
    <div class="parallax title" data-image="upload/223_1r140806_eat_spots_sobanndls.jpg" data-width="1440" data-height="960" data-content-height="60">
        <div class="parallax_title">
            <h2 class="ppb_title"></h2></div>
    </div>
    <div class="one" style="padding:50px 0 50px 0;">
        <div class="standard_wrapper">
            <div class="page_content_wrapper">
                <div class="inner">
                    <div style="margin:auto;width:100%;text-align:center;">
                        <h2 class="ppb_menu_title">TATLILAR</h2>
                        <br class="clear" />
                        <br/>
                        <div class="one_half ">
                            <div id="menu_3197" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">SÜTLAÇ</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Süt / Terme Pirinç / Şeker</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3172" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">ELMALI BAKLAVA</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Elma / Ceviz / Şeker</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3173" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">ÇİĞ KREMA İLE LOR TATLISI</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Lor / Un / Yumurta</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3174" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">SÜT HELVASI</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Süt / Vanilya / Nişasta</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3175" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">TELEME</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">İncir / Süt </div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3176" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">REVANİ</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Un / İrmik / Portakal</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3177" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">ARMUT TATLISI</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Armut / Vişne Suyu / Şeker</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">ÇITIR KADAYIFLI KIZARMIŞ DONDURMA</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Vanilyalı Dondurma / Kadayıf </div>
                            </div>
                        </div>
                        <div class="one_half">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">MEVSİM HOŞAFI</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt"></div>
                            </div>
                        </div>
                    </div>
                    <br class="clear" />
                </div>
            </div>
        </div>
    </div>
    <div class="parallax title" data-image="upload/223_1r140806_eat_spots_sobanndls.jpg" data-width="1440" data-height="960" data-content-height="60">
        <div class="parallax_title">
            <h2 class="ppb_title"></h2></div>
    </div>
    <div class="one" style="padding:50px 0 50px 0;">
        <div class="standard_wrapper">
            <div class="page_content_wrapper">
                <div class="inner">
                    <div style="margin:auto;width:100%;text-align:center;">
                        <h2 class="ppb_menu_title">İÇECEKLER</h2>
                        <br class="clear" />
                        <br/>
                        <div class="one_half ">
                            <div id="menu_3197" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">DEMİRHİNDİ ŞERBETİ</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Demirhindi / Su / Şeker</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3172" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">LİMONATA</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Limon / Nane / Şeker</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3173" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">AYRAN</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Yoğurt / Tuz / Su</div>
                            </div>
                        </div>
                        
                    </div>
                    <br class="clear" />
                </div>
            </div>
        </div>
    </div>
    <div class="parallax title" data-image="upload/223_1r140806_eat_spots_sobanndls.jpg" data-width="1440" data-height="960" data-content-height="60">
        <div class="parallax_title">
            <h2 class="ppb_title"></h2></div>
    </div>
    <div class="one" style="padding:50px 0 50px 0;">
        <div class="standard_wrapper">
            <div class="page_content_wrapper">
                <div class="inner">
                    <div style="margin:auto;width:100%;text-align:center;">
                        <h2 class="ppb_menu_title">KAHVALTI</h2>
                        <br class="clear" />
                        <br/>
                        <div class="one_half ">
                            <div id="menu_3197" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">II. BAYEZİD KAHVALTISI</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Kaymak / Bal ve Ezine Peyniri / Erzurum Göğermiş Peyniri / Kaşar Peyniri / Zeytin ve Ekşi Mayalı Ekmek</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3172" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">SERPME KAHVALTI</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Zeytinli Zahter / Ezine Peyniri / Erzurum Göğermiş Peyniri / Erzurum Civil Peyniri / Kars Eski Kaşar / Trakya Taze Kaşar / Van Otlu Peynir / Erzincan Şavak
                                Tulum Peyniri / Manda Tereyağı / Manda Kaymak / Tokat Bez Sucuk / Pastırma / Zeytin Çanağı (Halhalı Zeytin / Savranî Zeytin / Gemlik Sele) / Bal / Domates
                                Salatalık / Köy Biberi / Çilek Reçeli / Vişne Reçeli / Dut Pekmezi / Çalma Pekmez / Tereyağında Göz Yumurta / Sıcak Açık Ekmek / Puf Böreği / Simit / Cevizli Çörek / Süt veya Çay</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3173" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">EKSTRALAR</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Bezirgân Kebabı / Bal ve Kaymak / Tereyağında Göz Yumurta / Puf Böreği / Tereyağında Kangal Sucuk / Tereyağında Sucuklu Yumurta</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3174" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">PATATESLİ PİDE</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Haşlanmış Patates / Kuru Soğan / Baharatlar</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3175" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">MANTARLI PİDE</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">İstiridye Mantarı / Porçini Mantarı / Kuru Soğan / Baharatlar</div>
                            </div>
                        </div>
                        <div class="one_half last">
                            <div id="menu_3176" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">ISPANAKLI PİDE</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Ispanak / Pastırma / Peynir / Yumurta Sarısı</div>
                            </div>
                        </div>
                        <div class="one_half ">
                            <div id="menu_3177" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">PEYNİRLİ PİDE</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Lor Peyniri / Kaşar Peyniri / Ezine Peyniri</div>
                            </div>
                        </div>
                        <div class="one_half">
                            <div id="menu_3178" class="menu_content_classic">
                                <h5 class="menu_post">
                                    <span class="menu_title">ETLİ PİDE</span>
                                    <span class="menu_dots"></span></h5>
                                <div class="post_detail menu_excerpt">Bıçak Kıyması / Konkase Domates / Kuru Soğan</div>
                            </div>
                        </div>
                    </div>
                    <br class="clear" />
                </div>
            </div>
        </div>
    </div>
</div>