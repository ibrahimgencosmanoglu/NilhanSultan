
    <!-- Begin content -->
<div id="page_content_wrapper" class="hasbg withtopbar ">
    <div class="inner">

        <!-- Begin main content -->
        <div class="inner_wrapper">

            <div class="page_content_wrapper"></div>

            <div class="sidebar_content">

                <!-- Begin each blog post -->
                <div id="post-490" class="post-490 post type-post status-publish format-standard has-post-thumbnail hentry category-italine tag-recipe tag-shrimp tag-spaghetti">

                    <div class="post_wrapper">

                        <div class="post_content_wrapper">

                            <div class="post_header">
                                <div class="post_header_title">
                                    <h5><a href="http://themes.themegoods.com/grandrestaurant/demo1/black-spaghetti-with-rock-shrimp/" title="Black Spaghetti with Rock Shrimp">Nilhan Sultan Köşkü</a></h5>
                                    <div class="post_detail">
                                        
                                    </div>
                                </div>

                                <div class="post_img static">
                                    <a href="http://themes.themegoods.com/grandrestaurant/demo1/black-spaghetti-with-rock-shrimp/">
                                        <img src="images/deneme-yemek-2.jpg" alt="" class="" style="width:960px;height:365px;" />
                                    </a>
                                </div>

                                <br class="clear" />

                                <p>Nilhan Sultan Köşkü İstanbul Boğazı’nın en nadide kıyılarından birisi olan Paşalimanı’nda yer alır. Boğazın serin sularını sırtlara taşıyan rüzgâr, Köşk’ün tarihi sundurmalarına misafir olur. 19. yüzyıl Osmanlı mimarisinin en güzel örneklerinden biri olan Nilhan Sultan Köşkü de eşsiz kent İstanbul’un geçmişten bugüne ayakta kalan gelen en değerli yerlerindendir. </p>
                                <p>İstanbul Boğazı kıyısında yer alan Paşalimanı da tarihi dokusunu hâlâ kaybetmemiş olan Üsküdar’ın gözbebeği ilçesi. Camileri, çeşmeleri ve göz dolduran mimari yapısı ile Osmanlı tarihinin hatıralarını ayakta tutan Paşalimanı, tüm duyulara hitap eden eşsiz semtlerden biri. Uçsuz bucaksız maviliğin kenarında yer alan Paşalimanı’nda, Nilhan Sultan Köşkü’nün tarih kokan mimarisinde keyifli anlar sizleri bekliyor. </p>
                            </div>
                            <div class="post_share_bubble">
                                <div class="post_share_bubble_wrapper">
                                    <div id="share_post_490" class="social_share_bubble inline">
                                        <ul>
                                            <li><a title="Share On Facebook" target="_blank" href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a title="Share On Twitter" target="_blank" href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li><a title="Share On Pinterest" target="_blank" href="#"><i class="fa fa-pinterest"></i></a></li>
                                            <li><a title="Share On Google+" target="_blank" href="#"><i class="fa fa-google-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </div> <a href="javascript:;" class="post_share" data-share="share_post_490" data-parent="post-490"><i class="fa fa-share-alt"></i></a>
                            </div>

                        </div>

                    </div>
                    <div class="post_wrapper">

                        <div class="post_content_wrapper">

                            <div class="post_header">
                                <div class="post_header_title">
                                    <h5><a href="http://themes.themegoods.com/grandrestaurant/demo1/black-spaghetti-with-rock-shrimp/" title="Black Spaghetti with Rock Shrimp">Büyük Salon</a></h5>
                                    <div class="post_detail">
                                    </div>
                                </div>

                                <div class="post_img static">
                                    <a href="http://themes.themegoods.com/grandrestaurant/demo1/black-spaghetti-with-rock-shrimp/">
                                        <img src="images/deneme-yemek-2.jpg" alt="" class="" style="width:960px;height:365px;" />
                                    </a>
                                </div>

                                <br class="clear" />

                                <p>Kalabalık Osmanlı sofralarını günümüzde yaşatan bir mekân Büyük Salon. Osmanlı tarihinin yöresel tatlarına, aileniz ve sevdiklerinizle birlikte oturduğunuz bu büyük sofralarda varacaksınız.</p>
                            </div>
                            <div class="post_share_bubble">
                                <div class="post_share_bubble_wrapper">
                                    <div id="share_post_490" class="social_share_bubble inline">
                                        <ul>
                                            <li><a title="Share On Facebook" target="_blank" href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a title="Share On Twitter" target="_blank" href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li><a title="Share On Pinterest" target="_blank" href="#"><i class="fa fa-pinterest"></i></a></li>
                                            <li><a title="Share On Google+" target="_blank" href="#"><i class="fa fa-google-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </div> <a href="javascript:;" class="post_share" data-share="share_post_490" data-parent="post-490"><i class="fa fa-share-alt"></i></a>
                            </div>

                        </div>

                    </div>

                </div>
                <br class="clear" />

                <div id="post-1131" class="post-1131 post type-post status-publish format-standard has-post-thumbnail hentry category-cooking tag-dinning tag-recipe tag-restaurant tag-spaghetti">

                    <div class="post_wrapper">

                        <div class="post_content_wrapper">

                            <div class="post_header">
                                <div class="post_header_title">
                                    <h5><a href="#" title="Amazing Dining Experience Begins">Sarnıç Odası</a></h5>
                                    <div class="post_detail">
                                    </div>
                                </div>

                                <div class="post_img static">
                                    <a href="#">
                                        <img src="images/deneme-yemek-2.jpg" alt="" class="" style="width:960px;height:365px;" />
                                    </a>
                                </div>

                                <br class="clear" />

                                <p>Köşkün en estetik mekânlarından biri olan Sarnıç Odası, anılara doğru bir seyahate davet ediyor sizleri. Hem göze hem de damağa hitap eden bu seyahate, zengin Osmanlı lezzetleri  ortak oluyor.</p>
                            </div>
                            <div class="post_share_bubble">
                                <div class="post_share_bubble_wrapper">
                                    <div id="share_post_1131" class="social_share_bubble inline">
                                        <ul>
                                            <li><a title="Share On Facebook" target="_blank" href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a title="Share On Twitter" target="_blank" href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li><a title="Share On Pinterest" target="_blank" href="#"><i class="fa fa-pinterest"></i></a></li>
                                            <li><a title="Share On Google+" target="_blank" href="#"><i class="fa fa-google-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </div> <a href="javascript:;" class="post_share" data-share="share_post_1131" data-parent="post-1131"><i class="fa fa-share-alt"></i></a>
                            </div>

                        </div>

                    </div>

                </div>
                <br class="clear" />

                <div id="post-2769" class="post-2769 post type-post status-publish format-standard has-post-thumbnail hentry category-asian tag-recipe tag-restaurant tag-shrimp tag-spaghetti">

                    <div class="post_wrapper">

                    <div class="post_content_wrapper">

                        <div class="post_header">
                            <div class="post_header_title">
                                <h5><a href="#" title="Our Premium Food Recipe">Seyrengâh</a></h5>
                                    <div class="post_detail">
                                    </div>
                                </div>

                                <div class="post_img static">
                                    <a href="#">
                                        <img src="images/deneme-yemek-2.jpg" alt="" class="" style="width:960px;height:365px;" />
                                    </a>
                                </div>

                                <br class="clear" />

                                <p>İstanbul’un en keyifli semti Paşalimanı’nın eşsiz doğası içinde enfes Boğaz manzarasına karşı Osmanlı lezzetlerini tatmak isteyenlerin tercihi Seyrengâh. Boğaz’ın temiz rahiyası, dönem yemeklerinin tarifsiz kokularına Seyrengâh’ta karışıyor.</p>
                            </div>
                            <div class="post_share_bubble">
                                <div class="post_share_bubble_wrapper">
                                    <div id="share_post_2769" class="social_share_bubble inline">
                                        <ul>
                                            <li><a title="Share On Facebook" target="_blank" href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a title="Share On Twitter" target="_blank" href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li><a title="Share On Pinterest" target="_blank" href="#"><i class="fa fa-pinterest"></i></a></li>
                                            <li><a title="Share On Google+" target="_blank" href="#"><i class="fa fa-google-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </div> <a href="javascript:;" class="post_share" data-share="share_post_2769" data-parent="post-2769"><i class="fa fa-share-alt"></i></a>
                            </div>

                        </div>

                    </div>

                </div>
                <br class="clear" />

                <div id="post-1135" class="post-1135 post type-post status-publish format-standard has-post-thumbnail hentry category-cooking tag-cooking tag-cuisine tag-dinning tag-spaghetti">

                    <div class="post_wrapper">

                        <div class="post_content_wrapper">

                            <div class="post_header">
                                <div class="post_header_title">
                                    <h5><a href="#" title="Life is a combination of cooking">Sultan Locası</a></h5>
                                    <div class="post_detail">
                                    </div>
                                </div>

                                <div class="post_img static">
                                    <a href="#">
                                        <img src="images/deneme-yemek-2.jpg" alt="" class="" style="width:960px;height:365px;" />
                                    </a>
                                </div>

                                <br class="clear" />

                                <p>Tarihimizin eşsiz dokusu merkezinde özel hissettiren şık ve ferah tasarımıyla Sultan Locası, köşkün en keyifli noktalarından biri. Penceresi boğaza açılan bu salonda Osmanlı dönem mutfağının eşsiz lezzetleriyle buluşacaksınız. </p>
                            </div>
                            <div class="post_share_bubble">
                                <div class="post_share_bubble_wrapper">
                                    <div id="share_post_1135" class="social_share_bubble inline">
                                    <ul>
                                        <li><a title="Share On Facebook" target="_blank" href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a title="Share On Twitter" target="_blank" href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a title="Share On Pinterest" target="_blank" href="#"><i class="fa fa-pinterest"></i></a></li>
                                        <li><a title="Share On Google+" target="_blank" href="#"><i class="fa fa-google-plus"></i></a></li>
                                    </ul>
                                    </div>
                                </div> <a href="javascript:;" class="post_share" data-share="share_post_1135" data-parent="post-1135"><i class="fa fa-share-alt"></i></a>
                            </div>

                        </div>

                    </div>

                </div>
                <br class="clear" />


            </div>

                <div class="sidebar_wrapper">

                    <div class="sidebar_top"></div>

                    <div class="sidebar">

                        <div class="content">

                            <ul class="sidebar_widget">
                                <li id="text-3" class="widget widget_text">
                                    <h2 class="widgettitle">PAŞALİMANI</h2>
                                    <div class="textwidget">
                                        <p>Tarihi Lezzetlere Yolculuk Buradan Başlıyor</p>
                                    </div>
                                </li>
                                <li id="custom_flickr-3" class="widget Custom_Flickr">
                                    <h2 class="widgettitle">Galeri</h2>
                                    <ul class="flickr">
                                        <li>
                                            <a class="img_frame" target="_blank" href="upload/48544015562_9294520488_b.jpg" title="roasted carrots"><img src="upload/48544015562_9294520488_s.jpg" alt="roasted carrots" width="75" height="75" /></a>
                                        </li>
                                        <li>
                                            <a class="img_frame" target="_blank" href="upload/48528964047_de4b27d823_b.jpg" title="green mango and cucamelon salad"><img src="upload/48528964047_de4b27d823_s.jpg" alt="green mango and cucamelon salad" width="75" height="75" /></a>
                                        </li>
                                        <li>
                                            <a class="img_frame" target="_blank" href="upload/48489434421_4701e696dd_b.jpg" title="croissant morning"><img src="upload/48489434421_4701e696dd_s.jpg" alt="croissant morning" width="75" height="75" /></a>
                                        </li>
                                        <li>
                                            <a class="img_frame" target="_blank" href="upload/48317013731_f988b69c52_b.jpg" title="can&#039;t get enough of cherries"><img src="upload/48317013731_f988b69c52_s.jpg" alt="can&#039;t get enough of cherries" width="75" height="75" /></a>
                                        </li>
                                        <li>
                                            <a class="img_frame" target="_blank" href="upload/48308542466_151f2a66a3_b.jpg" title="cherry"><img src="upload/48308542466_151f2a66a3_s.jpg" alt="cherry" width="75" height="75" /></a>
                                        </li>
                                        <li>
                                            <a class="img_frame" target="_blank" href="upload/48092508442_dbd807762f_b.jpg" title="Romaine Wedge Caesar Salad"><img src="upload/48092508442_dbd807762f_s.jpg" alt="Romaine Wedge Caesar Salad" width="75" height="75" /></a>
                                        </li>
                                        <li>
                                            <a class="img_frame" target="_blank" href="upload/47015511494_a45979912a_b.jpg" title="roasted rhubarb with yogurt, mint, pistachio"><img src="upload/47015511494_a45979912a_s.jpg" alt="roasted rhubarb with yogurt, mint, pistachio" width="75" height="75" /></a>
                                        </li>
                                        <li>
                                            <a class="img_frame" target="_blank" href="upload/46968818334_b4bb23dc19_b.jpg" title="radish pod and tomato salad"><img src="upload/46968818334_b4bb23dc19_s.jpg" alt="radish pod and tomato salad" width="75" height="75" /></a>
                                        </li>
                                        <li>
                                            <a class="img_frame" target="_blank" href="upload/40747094363_16c3b23b2f_b.jpg" title="macarons and tea"><img src="upload/40747094363_16c3b23b2f_s.jpg" alt="macarons and tea" width="75" height="75" /></a>
                                        </li>
                                    </ul>
                                <br class="clear" />
                                </li>
                            </ul>

                        </div>

                    </div>
                    <br class="clear" />

                    <div class="sidebar_bottom"></div>
                </div>
            </div>


        </div>
        <br class="clear" />
        <br/>
    </div>
</div>
