	<div class="one withsmallpadding withbg " style="color:#ffffff;background-image:url(images/1440x1440-dummy1.jpg);background-size:cover; ">
		<div class="standard_wrapper">
			<div class="page_content_wrapper" style="text-align:center">
				<div class="inner">
					<div class="testimonial_slider_wrapper">
						<div class="flexslider" data-height="750">
							<ul class="slides">
								<li>
									<div class="testimonial_slider_wrapper">
										<div class="testimonial_stars"></div>ŞİFA KAYNAĞI GASTRONOMİ
										<div class="testimonial_slider_meta"></div>
									</div>
								</li>
								<li>
									<div class="testimonial_slider_wrapper">
										<div class="testimonial_stars"></div>BOĞAZ’DA NADİDE BİR GÜZEL: NİLHAN SULTAN PAŞALİMANI KÖŞKÜ 
										<div class="testimonial_slider_meta"></div>
									</div>
								</li>
								<li>
									<div class="testimonial_slider_wrapper">
										<div class="testimonial_stars"></div>RUHUNUZU ŞİFAYLA BESLEYİN
										<div class="testimonial_slider_meta"></div>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>