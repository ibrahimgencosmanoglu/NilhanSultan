<div class="divider one">&nbsp;</div>
<div class="parallax " data-image="/images/1440x810-dummy1" data-width="1440" data-height="810" data-content-height="60"></div>
<div class="divider one">&nbsp;</div>
<div class="ppb_menu_multiple one nopadding " style="padding:40px 0 40px 0;">
	<div class="page_content_wrapper fullwidth">
		<div class="standard_wrapper">
			<div class="portfolio_filter_wrapper two_cols gallery portfolio-content section content clearfix">
				<div class="element classic2_cols">
					<div class="one_half gallery2 filterable static">
						<div class="menu_multiple_wrapper" style="background:#000000;border: 1px solid #000000;">
							<h2 class="ppb_title" style="color:#ffffff;">Menü</h2>
							<div class="menu_multiple_content" style="color:#ffffff;">
								<p>Nilhan Sultan Köşkü Paşalimanı’nın sultanlara layık yemekleri mevsimsel hasat dönemlerine göre doğal olarak yetiştirilen ürünlerle hazırlanır. Bu nedenle yaz ve kış aylarında bazı farklılıklar göstermektedir. Deniz ürünleri mevsimine göre Bozcaada ve Çanakkale kıyılarındaki denizlerden tedarik edilmektedir.  Yemeklerimizde tereyağı ve zeytinyağı dışında yağ kullanılmaz.</p>
							</div>
						</div>
					</div>
				</div>
				<div class="element classic2_cols">
					<div class="one_half gallery2 filterable static">
						<div class="menu_multiple_wrapper">
							<h2 class="ppb_menu_title">BAŞLANGIÇLAR</h2>
							<br class="clear" />
							<br/>
							<div class="one">
								<div id="menu_3179" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">Mastabe</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">Süzme Yoğurt / Pazı / Çörek otu</div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3179" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">ZEYTİNYAĞLI REZENE</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">Rezene / Portakal Suyu / Portakal Dilimleri</div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3180" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">TERBİYELİ LEVREK</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">Levrek / Rezene / Sirke</div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3182" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">VİŞNELİ ZEYTİNYAĞLI YAPRAK SARMA</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">Pirinç / Kuş Üzümü / Dolmalık Fıstık </div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3182" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">ENGİNAR VE ZAHTERLİ KARİDES SALATASI</span>
				<span class="menu_dots"></h5>
									<div class="post_detail menu_excerpt">Enginar / Karides / Zahter </div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3182" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">KORUK SULU ÇOBAN SALATA</span>
				<span class="menu_dots"></h5>
									<div class="post_detail menu_excerpt">Domates / Salatalık / Köy Biberi</div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3182" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">KABAK TAVA</span>
				<span class="menu_dots"></h5>
									<div class="post_detail menu_excerpt">Sakız Kabağı / Un / Nişasta</div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3182" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">KARİDES PİLAKİSİ</span>
				<span class="menu_dots"></h5>
									<div class="post_detail menu_excerpt">Karides / Havuç / Kereviz Sapı</div>
								</div>
							</div>
							<br class="clear" />
						</div>
					</div>
				</div>
				<div class="element classic2_cols">
					<div class="one_half gallery2 filterable static">
						<div class="menu_multiple_wrapper">
							<h2 class="ppb_menu_title">ANA YEMEKLER</h2>
							<br class="clear" />
							<br/>
							<div class="one">
								<div id="menu_3183" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">KANLICA MANTAR, ARPACIK SOĞAN İLE TEREYAĞLI VE SARIMSAKLI İSKORPİT KAVURMA</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">İskorpit Balığı / Sarımsak / Kanlıca Mantar</div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3184" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">AL’A NAZİK</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">Patlıcan / Kuzu Eti / Sarımsak</div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3185" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">HÜNKAR BEĞENDİ</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">Dana Eti / Salça / Baharatlar</div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3185" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">KEBAB-I MAKİYAN (1469)</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">Tavuk But / Yenibahar / Tarçın</div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3185" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">KUZU İNCİK</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">Kuzu İncik / Tereyağı / Tuz</div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3185" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">DÖVME KEŞKEK</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">Buğday / Et Suyu / Pul Biber</div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3185" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">KIYMA PÜRYANİ YUFKADA (1764)</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">Kuzu Eti Kıyması / Tavuk Eti Kıyması / Anason</div>
								</div>
							</div>
							<br class="clear" />
						</div>
					</div>
				</div>
				<div class="element classic2_cols">
					<div class="one_half gallery2 filterable static">
						<div class="menu_multiple_wrapper">
							<h2 class="ppb_menu_title">TATLILAR</h2>
							<br class="clear" />
							<br/>
							<div class="one">
								<div id="menu_3171" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">ELMALI BAKLAVA</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">Elma / Ceviz / Şeker</div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3172" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">TELEME</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">İncir / Süt </div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3172" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">REVANİ</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">Un / İrmik / Portakal</div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3172" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">ÇİĞ KREMA İLE LOR TATLISI</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">Lor / Un / Yumurta</div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3173" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">SÜT HELVASI</span>
				<span class="menu_dots"></span></h5>
									<div class="post_detail menu_excerpt">Süt / Vanilya / Nişasta</div>
								</div>
							</div>
							<br class="clear" />
						</div>
					</div>
				</div>
				<div class="element classic2_cols">
					<div class="one_half gallery2 filterable static">
						<div class="menu_multiple_wrapper">
							<h2 class="ppb_menu_title">Kahveler</h2>
							<br class="clear" />
							<br/>
							<div class="one">
								<div id="menu_2878" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">Gar Kahvesi</span>
				<span class="menu_dots"></h5>
				<div class="post_detail menu_excerpt"></div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3186" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">Tatar Kahvesi</span>
				<span class="menu_dots"></span></h5>
				<div class="post_detail menu_excerpt"></div>
								</div>
							</div>
							<div class="one">
								<div id="menu_3187" class="menu_content_classic">
									<h5 class="menu_post">
				<span class="menu_title">Mihrimah Sultan Kahvesi </span>
				<span class="menu_dots"></span></h5>
				<div class="post_detail menu_excerpt"></div>
								</div>
							</div>
							<br class="clear" />
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
