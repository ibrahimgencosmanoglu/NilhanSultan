<div class="divider one">&nbsp;</div>
<div class="one ppb_card_two_cols_with_image" style="padding:70px 0 50px 0 !important;position:relative;padding:40px 0 40px 0;">
	<div class="standard_wrapper">
		<div class="page_content_wrapper">
			<div class="inner">
				<div class="one_half parallax_scroll_image" style="width:65%;">
					<div class="image_classic_frame expand">
						<div class="image_wrapper">
							<a href="upload/photo-1421622548261-c45bfe178854.jpg" class="img_frame"><img src="../images/1440x962-dummy1.jpg" class="portfolio_img" alt="" /></a>
						</div>
					</div>
				</div>
				<div class="one_half last parallax_scroll" style="width:40%;position:absolute;right:90px;padding:40px;background:#ffffff;border: 1px solid #e1e1e1;" data-stellar-ratio="1.3">
					<h2 class="ppb_title">Boğaz'ın Kalbinden Tarihî Lezzetler </h2>
					<div class="page_header_sep left"></div>İstanbul Boğazı’nda bakışın, Tarihî Yarımada’dan Ortaköy’e uzanabildiği, sakin taraçalarda keyifle kahvenizi yudumlayabileceğiniz, gerçek Osmanlı dönem mutfaklarının en güzel lezzetlerini bir Osmanlı köşkünde tadabileceğiniz bir mekan hayal edin. 
					Burada boğazın serin sularını sırtlara taşıyan rüzgâr, Köşk’ün tarihi sundurmalarına misafir olur. 19. yüzyıl Osmanlı mimarisinin aslına uygun inşa edilen en güzel örneklerinden birisi olan köşkte yemekler bugüne misafir olur. 
				</div>
				<br class="clear" />
			</div>
		</div>
	</div>
</div>
<div class="divider one">&nbsp;</div>