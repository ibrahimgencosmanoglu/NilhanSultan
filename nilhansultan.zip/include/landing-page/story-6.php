<div class="one withsmallpadding ppb_header " style="padding-bottom:0px !important;text-align:center;padding:50px 0 50px 0;">
	<div class="standard_wrapper">
		<div class="page_content_wrapper">
			<div class="inner">
				<div style="margin:auto;width:100%%;">
					<h2 class="ppb_title" style="">Rezervasyon</h2>
					<div class="page_header_sep center"></div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="one withsmallpadding ppb_text" style="padding-top: 20px !important;padding:70px 0 70px 0;">
	<div class="standard_wrapper">
		<div class="page_content_wrapper">
			<div class="inner">
				<div style="margin:auto;width:100%;text-align:center;">
					<p>Nilhan Sultan Paşalimanı’na 0216 310 1299 numarasından rezervasyon yaptırabilirsiniz. </p>
					
				</div>
			</div>
		</div>
	</div>
</div>