<div class="one ppb_card_two_cols_with_image" style="padding:70px 0 50px 0 !important;position:relative;padding:40px 0 40px 0;">
	<div class="standard_wrapper">
		<div class="page_content_wrapper">
			<div class="inner">
				<div class="one_half parallax_scroll" style="width:40%;position:absolute;left:90px;padding:40px;z-index:2;block !important;background:#ffffff;border: 1px solid #e1e1e1;" data-stellar-ratio="1.3">
					<h2 class="ppb_title"><span class="ppb_title_first" >Osmanlı </span>Dönem Mutfakları</h2>
					<div class="page_header_sep left"></div>Padişah macunlarından, Şaman şerbetlerine kadar her yüz güldüren neşenin, mutluluk veren lezzetin menşei oldu bu topraklar. Görkemin en yüksek noktasına erişen Padişahlara, Sultanlara sunulan nice özel yiyeceklerin sırlarını sakladı binlerce yıldır. Bu toprakların lezzet sırları, şifa kültürü zamanın tahribatına karşı koyan mutfak kültürü şimdi sultanlara layık sofralarla Nilhan Sultan Köşkü Paşalimanı’nda.</div>
				<div class="one_half parallax_scroll_image last" style="width:65%;">
					<div class="image_classic_frame expand">
						<div class="image_wrapper">
							<a href="upload/photo-1414235077428-338989a2e8c0.jpg" class="img_frame"><img src="../images/1440x960-dummy1.jpg" class="portfolio_img" alt="" /></a>
						</div>
					</div>
				</div>
				<br class="clear" />
			</div>
		</div>
	</div>
</div>