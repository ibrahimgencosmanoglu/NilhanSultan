﻿    <div class="mobile_menu_wrapper">
        <a id="close_mobile_menu" href="javascript:;"><i class="fa fa-close"></i></a>

        <form role="search" method="get" name="searchform" id="searchform" action="https://themes.themegoods.com/grandrestaurant/demo6/">
            <div>
                <input type="text" value="" name="s" id="s" autocomplete="off" placeholder="Search..." />
                <button>
                    <i class="fa fa-search"></i>
                </button>
            </div>
            <div id="autocomplete"></div>
        </form>

        <div class="menu-main-menu-container">
            <ul id="mobile_main_menu" class="mobile_main_nav">
                <li class="menu-item current-menu-item"><a href="/" aria-current="page">Ana Sayfa</a></li>
                <li class="menu-item"><a href="menu">Menü</a></li>
                <li class="menu-item"><a href="hakkimizda">Hakkımızda</a></li>
                <li class="menu-item"><a href="osmanli-donem-mutfaklari">Osmanlı Dönem Mutfakları</a></li>
                <li class="menu-item"><a href="kosk">Köşk</a></li>
            </ul>
        </div>
        <!-- Begin Reservation 
        <a href="javascript:;" id="tg_sidemenu_reservation" class="button ">Reservation</a>
         End Reservation -->

        <!-- Begin side menu sidebar -->
        <div class="page_content_wrapper">
            <div class="sidebar_wrapper">
                <div class="sidebar">

                    <div class="content">

                        <ul class="sidebar_widget">
                            <li id="text-8" class="widget widget_text">
                                <div class="textwidget">
                                    <p><img src="upload/logo_footer.png" alt="" width="142" height="42" /></p>
                                    <div style="margin-bottom:20px;">
                                        Dolor church-key veniam, fap Bushwick mumblecore irure Vice consectetur 3 wolf moon sapiente literally quinoa.
                                    </div>
                                    <p><img class="alignnone size-full wp-image-3389" src="upload/signature.png" alt="signature" width="232" height="56" /></p>
                                </div>
                            </li>
                        </ul>

                    </div>

                </div>
            </div>
        </div>
        <!-- End side menu sidebar -->
    </div>